# Nyptune
* Audio Distribution/Sharings Platform

## Features
1.  MP3 file upload support
2.  User account creation 
3.  Homepage audio feed  
4.  The user is able to login using their account credentials and log out.

## TODO
1. Replay, Repeat, and Shuffle options
2. Play counter to keep track of the number of listens
3. Image upload option with respective audio file
4. User profiles
5. Like counter for the number of favorites

